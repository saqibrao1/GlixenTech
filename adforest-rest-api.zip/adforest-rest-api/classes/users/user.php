<?php
  /**
  * Add REST API support to an already registered post type.
  */
